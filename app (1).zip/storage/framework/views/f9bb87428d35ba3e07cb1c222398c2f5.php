
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-6 mx-auto">
            <h1 class="h3 mb-4">Edit Shop Category</h1>

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('shop-categories.update', $shopCategory)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="mb-2">
                            <label class="form-label fw-bold">Parent Category</label>
                            <p class="form-control-plaintext fw-bold text-primary fs-5">
                                <?php echo e($shopCategory->name); ?>

                            </p>
                        </div>

                        
                        <div class="mb-4">
                            <label for="slug" class="form-label fw-bold">Parent Category Slug *</label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="slug"
                                   name="slug"
                                   value="<?php echo e(old('slug', $shopCategory->slug)); ?>"
                                   placeholder="e.g., electronics"
                                   required>
                            <small class="text-muted">Changing the slug will also update the category name</small>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">
                                Subcategories
                                <span class="text-muted fw-normal">(children)</span>
                            </label>

                            <div id="subcategories-container">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $shopCategory->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="subcategory-row border rounded p-2 mb-2">
                                        <div class="mb-2">
                                            <input type="text"
                                                   class="form-control sub-name"
                                                   name="subcategories[<?php echo e($index); ?>][name]"
                                                   placeholder="Subcategory name e.g., Laptops"
                                                   value="<?php echo e(old('subcategories.'.$index.'.name', $subcat->name)); ?>"
                                                   oninput="syncSlug(this)">
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-text text-muted" style="font-size:.8rem;">slug</span>
                                            <input type="text"
                                                   class="form-control sub-slug"
                                                   name="subcategories[<?php echo e($index); ?>][slug]"
                                                   placeholder="Auto-generated"
                                                   value="<?php echo e(old('subcategories.'.$index.'.slug', $subcat->slug)); ?>">
                                            <button type="button" class="btn btn-outline-danger" onclick="removeSubcategory(this)">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="subcategory-row border rounded p-2 mb-2">
                                        <div class="mb-2">
                                            <input type="text"
                                                   class="form-control sub-name"
                                                   name="subcategories[0][name]"
                                                   placeholder="Subcategory name e.g., Laptops"
                                                   oninput="syncSlug(this)">
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-text text-muted" style="font-size:.8rem;">slug</span>
                                            <input type="text"
                                                   class="form-control sub-slug"
                                                   name="subcategories[0][slug]"
                                                   placeholder="Auto-generated">
                                            <button type="button" class="btn btn-outline-danger" onclick="removeSubcategory(this)">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <button type="button" class="btn btn-outline-primary btn-sm mt-2" onclick="addSubcategory()">
                                + Add Subcategory
                            </button>
                            <div class="form-text text-muted mt-1">
                                Slugs are auto-generated from the subcategory name.
                            </div>
                        </div>

                        
                        <div class="mb-4">
                            <div class="form-check form-switch">
                                <input class="form-check-input"
                                       type="checkbox"
                                       id="active"
                                       name="active"
                                       value="1"
                                       <?php echo e(old('active', $shopCategory->active) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="active">Active</label>
                            </div>
                        </div>

                        
                        <div class="alert alert-light mb-4">
                            <small class="text-muted">
                                Created: <?php echo e($shopCategory->created_at->format('M d, Y')); ?> |
                                Updated: <?php echo e($shopCategory->updated_at->format('M d, Y')); ?>

                            </small>
                        </div>

                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('shop-categories.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function toSlug(value) {
        return value
            .toLowerCase()
            .trim()
            .replace(/[^\w\s-]/g, '')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-');
    }

    function syncSlug(nameInput) {
        const row       = nameInput.closest('.subcategory-row');
        const slugInput = row.querySelector('.sub-slug');
        slugInput.value = toSlug(nameInput.value);
    }

    let rowIndex = <?php echo e($shopCategory->subcategories->count() ?: 1); ?>;

    function addSubcategory() {
        const container = document.getElementById('subcategories-container');
        const row       = document.createElement('div');
        row.className   = 'subcategory-row border rounded p-2 mb-2';
        row.innerHTML   = `
            <div class="mb-2">
                <input type="text"
                       class="form-control sub-name"
                       name="subcategories[${rowIndex}][name]"
                       placeholder="Subcategory name e.g., Laptops"
                       oninput="syncSlug(this)">
            </div>
            <div class="input-group">
                <span class="input-group-text text-muted" style="font-size:.8rem;">slug</span>
                <input type="text"
                       class="form-control sub-slug"
                       name="subcategories[${rowIndex}][slug]"
                       placeholder="Auto-generated">
                <button type="button" class="btn btn-outline-danger" onclick="removeSubcategory(this)">
                    <i class="bi bi-trash"></i>
                </button>
            </div>
        `;
        container.appendChild(row);
        row.querySelector('.sub-name').focus();
        rowIndex++;
    }

    function removeSubcategory(button) {
        const container = document.getElementById('subcategories-container');
        if (container.children.length > 1) {
            button.closest('.subcategory-row').remove();
        } else {
            container.querySelectorAll('input').forEach(i => i.value = '');
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/shop-categories/edit.blade.php ENDPATH**/ ?>