
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="h3 mb-4">Edit Shop Product</h1>

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.shop-products.update', $shopProduct)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <div class="mb-3">
                            <label for="product_name" class="form-label fw-bold">Product Name *</label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="product_name" name="product_name"
                                   value="<?php echo e(old('product_name', $shopProduct->product_name)); ?>"
                                   required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="row">
                            
                            <div class="col-md-4 mb-3">
                                <label for="status" class="form-label fw-bold">Status *</label>
                                <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="status" name="status" required>
                                    <option value="in_stock"     <?php echo e(old('status', $shopProduct->status) === 'in_stock'     ? 'selected' : ''); ?>>In Stock</option>
                                    <option value="out_of_stock" <?php echo e(old('status', $shopProduct->status) === 'out_of_stock' ? 'selected' : ''); ?>>Out of Stock</option>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label for="price" class="form-label fw-bold">Price (RWF) *</label>
                                <div class="input-group">
                                    <span class="input-group-text">RWF</span>
                                    <input type="number"
                                           class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="price" name="price"
                                           value="<?php echo e(old('price', $shopProduct->price)); ?>"
                                           min="0" step="1" required>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label for="working_days" class="form-label fw-bold">Working Days *</label>
                                <input type="number"
                                       class="form-control <?php $__errorArgs = ['working_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="working_days" name="working_days"
                                       value="<?php echo e(old('working_days', $shopProduct->working_days)); ?>"
                                       min="1" required>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['working_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox"
                                       class="form-check-input"
                                       id="is_popular" 
                                       name="is_popular"
                                       value="1"
                                       <?php echo e(old('is_popular', $shopProduct->is_popular) ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-bold" for="is_popular">
                                    <i class="bi bi-star-fill" style="color: #ffc107;"></i>
                                    Mark as Popular Product
                                </label>
                                <small class="d-block text-muted mt-1">
                                    ✅ When checked: Shows in BOTH popular section AND shop page  
                                    ❌ When unchecked: Shows ONLY in shop page
                                </small>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <label for="description" class="form-label fw-bold">Description</label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="description" name="description"
                                      rows="3"><?php echo e(old('description', $shopProduct->description)); ?></textarea>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="row">
                            
                            <div class="col-md-6 mb-3">
                                <label for="shop_category_id" class="form-label fw-bold">Parent Category *</label>
                                <select class="form-select <?php $__errorArgs = ['shop_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="shop_category_id" name="shop_category_id" required>
                                    <option value="">— Select Parent Category —</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>"
                                                data-subcategories="<?php echo e($cat->subcategories->toJson()); ?>"
                                                <?php echo e(old('shop_category_id', $shopProduct->shop_category_id) == $cat->id ? 'selected' : ''); ?>>
                                            <?php echo e($cat->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['shop_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <div class="col-md-6 mb-3">
                                <label for="subcategory_id" class="form-label fw-bold">Subcategory</label>
                                <select class="form-select <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="subcategory_id" name="subcategory_id">
                                    <option value="">— Select Subcategory —</option>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Features</label>
                            <div id="features-container">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = old('features', $shopProduct->features ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="input-group mb-2">
                                        <input type="text" class="form-control"
                                               name="features[]"
                                               value="<?php echo e($feature); ?>"
                                               placeholder="e.g., Fast Charging">
                                        <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="input-group mb-2">
                                        <input type="text" class="form-control" name="features[]" placeholder="e.g., Fast Charging">
                                        <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="addFeature()">
                                + Add Feature
                            </button>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Specifications</label>
                            <div id="specs-container">
                                <?php $specs = old('specifications', $shopProduct->specifications ?? []); ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $specs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="spec-row d-flex gap-2 mb-2">
                                        <input type="text" class="form-control"
                                               name="specifications[<?php echo e($i); ?>][label]"
                                               placeholder="Label (e.g., RAM)"
                                               value="<?php echo e($spec['label'] ?? ''); ?>">
                                        <input type="text" class="form-control"
                                               name="specifications[<?php echo e($i); ?>][value]"
                                               placeholder="Value (e.g., 8GB)"
                                               value="<?php echo e($spec['value'] ?? ''); ?>">
                                        <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="spec-row d-flex gap-2 mb-2">
                                        <input type="text" class="form-control" name="specifications[0][label]" placeholder="Label (e.g., RAM)">
                                        <input type="text" class="form-control" name="specifications[0][value]" placeholder="Value (e.g., 8GB)">
                                        <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="addSpec()">
                                + Add Specification
                            </button>
                        </div>

                        
                        <div class="mb-3">
                            <label for="thumbnail" class="form-label fw-bold">Thumbnail Image</label>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->thumbnail): ?>
                                <div class="mb-2">
                                    <img src="<?php echo e(asset('public/assets/' . $shopProduct->thumbnail)); ?>"
                                         class="rounded"
                                         style="width:100px;height:100px;object-fit:cover;"
                                         alt="Current Thumbnail">
                                    <small class="text-muted d-block mt-1">Current thumbnail — upload new to replace</small>
                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <input type="file"
                                   class="form-control <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="thumbnail" name="thumbnail"
                                   accept="image/*"
                                   onchange="previewThumbnail(this)">
                            <div id="thumbnail-preview" class="mt-2"></div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div class="mb-4">
                            <label for="images" class="form-label fw-bold">Other Images</label>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($shopProduct->images)): ?>
                                <div class="d-flex flex-wrap gap-2 mb-2">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $shopProduct->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset('public/assets/' . $img)); ?>"
                                             class="rounded"
                                             style="width:80px;height:80px;object-fit:cover;"
                                             alt="Product Image">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                                <small class="text-muted d-block mb-2">Upload new images to replace all existing ones</small>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <input type="file"
                                   class="form-control <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="images" name="images[]"
                                   accept="image/*" multiple
                                   onchange="previewImages(this)">
                            <div id="images-preview" class="d-flex flex-wrap gap-2 mt-2"></div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div class="alert alert-light mb-4">
                            <small class="text-muted">
                                Created: <?php echo e($shopProduct->created_at->format('M d, Y')); ?> |
                                Updated: <?php echo e($shopProduct->updated_at->format('M d, Y')); ?>

                            </small>
                        </div>

                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">Update Product</button>
                            <a href="<?php echo e(route('admin.shop-products.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // ── Category → Subcategory ─────────────────────────────────────────────
    const categorySelect    = document.getElementById('shop_category_id');
    const subcategorySelect = document.getElementById('subcategory_id');
    const oldSubcat         = "<?php echo e(old('subcategory_id', $shopProduct->subcategory_id)); ?>";

    function loadSubcategories() {
        const selected = categorySelect.options[categorySelect.selectedIndex];
        subcategorySelect.innerHTML = '<option value="">— Select Subcategory —</option>';
        if (!selected || !selected.dataset.subcategories) return;
        const subs = JSON.parse(selected.dataset.subcategories);
        subs.forEach(sub => {
            const opt       = document.createElement('option');
            opt.value       = sub.id;
            opt.textContent = sub.name;
            if (oldSubcat == sub.id) opt.selected = true;
            subcategorySelect.appendChild(opt);
        });
    }

    categorySelect.addEventListener('change', loadSubcategories);
    loadSubcategories();

    // ── Features ──────────────────────────────────────────────────────────
    function addFeature() {
        const container = document.getElementById('features-container');
        const group     = document.createElement('div');
        group.className = 'input-group mb-2';
        group.innerHTML = `
            <input type="text" class="form-control" name="features[]" placeholder="e.g., Fast Charging">
            <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                <i class="bi bi-trash"></i>
            </button>`;
        container.appendChild(group);
        group.querySelector('input').focus();
    }

    // ── Specifications ─────────────────────────────────────────────────────
    let specIndex = <?php echo e(count($shopProduct->specifications ?? []) ?: 1); ?>;

    function addSpec() {
        const container = document.getElementById('specs-container');
        const row       = document.createElement('div');
        row.className   = 'spec-row d-flex gap-2 mb-2';
        row.innerHTML   = `
            <input type="text" class="form-control" name="specifications[${specIndex}][label]" placeholder="Label (e.g., RAM)">
            <input type="text" class="form-control" name="specifications[${specIndex}][value]" placeholder="Value (e.g., 8GB)">
            <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                <i class="bi bi-trash"></i>
            </button>`;
        container.appendChild(row);
        row.querySelector('input').focus();
        specIndex++;
    }

    function removeRow(btn) {
        btn.closest('.input-group, .spec-row').remove();
    }

    // ── Image Previews ─────────────────────────────────────────────────────
    function previewThumbnail(input) {
        const preview = document.getElementById('thumbnail-preview');
        preview.innerHTML = '';
        if (input.files && input.files[0]) {
            const img     = document.createElement('img');
            img.src       = URL.createObjectURL(input.files[0]);
            img.className = 'rounded';
            img.style     = 'width:100px;height:100px;object-fit:cover;';
            preview.appendChild(img);
        }
    }

    function previewImages(input) {
        const preview = document.getElementById('images-preview');
        preview.innerHTML = '';
        Array.from(input.files).forEach(file => {
            const img     = document.createElement('img');
            img.src       = URL.createObjectURL(file);
            img.className = 'rounded';
            img.style     = 'width:80px;height:80px;object-fit:cover;';
            preview.appendChild(img);
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/shop-products/edit.blade.php ENDPATH**/ ?>