
<?php $__env->startSection('content'); ?>

<main class="py-5 py-md-20">
    <div class="container">

        
        <a href="<?php echo e(route('shop')); ?>" class="d-inline-flex align-items-center gap-2 text-decoration-none text-muted mb-4" style="font-size: 0.95rem;">
            <i class="bi bi-arrow-left"></i>
            Back to Shop
        </a>

        
        <div class="row g-5 mt-2">
            
            <div class="col-12 col-lg-5">
                <div class="rounded-3 overflow-hidden bg-light shadow-sm">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->thumbnail): ?>
                        <img src="<?php echo e(asset('public/assets/' . $shopProduct->thumbnail)); ?>"
                             alt="<?php echo e($shopProduct->product_name); ?>"
                             class="w-100 img-fluid"
                             style="aspect-ratio: 1 / 1; object-fit: cover;">
                    <?php else: ?>
                        <div class="d-flex align-items-center justify-content-center"
                             style="aspect-ratio: 1 / 1; font-size: 4rem; color: #ccc;">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="d-flex gap-2 mt-4 flex-wrap">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->status === 'in_stock'): ?>
                        <span class="badge bg-success" style="font-size: 0.8rem;">In Stock</span>
                    <?php else: ?>
                        <span class="badge bg-danger" style="font-size: 0.8rem;">Out of Stock</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->category): ?>
                        <span class="badge bg-light text-dark" style="font-size: 0.8rem;">
                            <?php echo e($shopProduct->category->name); ?>

                        </span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->images && count($shopProduct->images) > 0): ?>
                    <div class="mt-4">
                        <h6 class="text-muted mb-3" style="font-size: 0.9rem;">Gallery</h6>
                        <div class="row g-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $shopProduct->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-4">
                                    <img src="<?php echo e(asset('public/assets/' . $image)); ?>"
                                         alt="Gallery"
                                         class="w-100 rounded-2 shadow-sm"
                                         style="height: 100px; object-fit: cover; cursor: pointer; transition: all 0.3s ease;"
                                         data-bs-toggle="modal"
                                         data-bs-target="#imageModal"
                                         onclick="document.getElementById('modalImage').src = this.src;">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            
            <div class="col-12 col-lg-7">
                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->category): ?>
                    <span class="badge bg-secondary-subtle text-dark rounded-pill px-3 py-2" style="font-size: 0.85rem;">
                        <?php echo e($shopProduct->category->name); ?>

                    </span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <h1 class="mt-3 fw-bold" style="font-size: 2.5rem;">
                    <?php echo e($shopProduct->product_name); ?>

                </h1>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->description): ?>
                    <p class="mt-4 text-muted lead">
                        <?php echo e($shopProduct->description); ?>

                    </p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <div class="mt-5 rounded-3 p-4 shadow-sm" style="background-color: #f8f9fa;">
                    <div class="d-flex align-items-end gap-2">
                        <span class="fw-bold" style="font-size: 2.5rem; color: #16a34a;">
                            RWF <?php echo e(number_format($shopProduct->price, 0, '.', ',')); ?>

                        </span>
                    </div>

                    
                    <div class="d-flex align-items-center gap-2 mt-3 text-muted" style="font-size: 0.95rem;">
                        <i class="bi bi-clock"></i>
                        <span>Delivery: <?php echo e($shopProduct->working_days); ?> working day(s)</span>
                    </div>

                    
                    <?php
                        $whatsappMessage = urlencode(
                            "Hi TRESCA Hub! I'm interested in: *" . $shopProduct->product_name . "*\n" .
                            "Price: RWF " . number_format($shopProduct->price, 0, '.', ',') . "\n" .
                            "Please share more details.\n\n" .
                            "Product Link: " . route('shop-products.show', $shopProduct)
                        );
                        $whatsappUrl = "https://wa.me/250780290040?text=" . $whatsappMessage;
                    ?>

                    <div class="mt-4">
                        <a href="<?php echo e($whatsappUrl); ?>" target="_blank" class="btn btn-success btn-lg w-100 gap-2" style="background-color: #25d366; border-color: #25d366;">
                            <i class="bi bi-whatsapp"></i>
                            Order via WhatsApp
                        </a>
                    </div>

                    
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->status === 'out_of_stock'): ?>
                        <div class="alert alert-warning mt-3 mb-0" role="alert">
                            <i class="bi bi-exclamation-triangle"></i>
                            This product is currently out of stock. Contact us for availability.
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->features && count($shopProduct->features) > 0): ?>
                    <div class="mt-6">
                        <h5 class="fw-bold">Features & What's Included</h5>
                        <div class="row g-3 mt-2">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $shopProduct->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-sm-6">
                                    <div class="d-flex gap-3 p-3 bg-light rounded-3">
                                        <div class="d-flex align-items-center justify-content-center rounded-circle bg-success text-white" style="width: 24px; height: 24px; flex-shrink: 0; font-size: 0.75rem;">
                                            ✓
                                        </div>
                                        <span class="text-sm" style="font-size: 0.95rem;"><?php echo e($feature); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($shopProduct->specifications && count($shopProduct->specifications) > 0): ?>
                    <div class="mt-6">
                        <h5 class="fw-bold">Specifications</h5>
                        <div class="mt-3 rounded-3 overflow-hidden shadow-sm">
                            <div class="table-responsive">
                                <table class="table table-sm mb-0">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $shopProduct->specifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-muted fw-semibold" style="padding: 0.75rem 1rem;">
                                                <?php echo e($spec['label'] ?? $spec); ?>

                                            </td>
                                            <td class="fw-semibold text-end" style="padding: 0.75rem 1rem;">
                                                <?php echo e($spec['value'] ?? ''); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <div class="mt-4">
                    <a href="<?php echo e($whatsappUrl); ?>" target="_blank" class="btn btn-outline-secondary gap-2">
                        <i class="bi bi-chat-dots"></i>
                        Ask Questions via WhatsApp
                    </a>
                </div>
            </div>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($related) && $related->count() > 0): ?>
            <section class="mt-12 pt-5 border-top">
                <h3 class="fw-bold mb-4">Related Products</h3>
                <div class="row g-4">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-sm-6 col-lg-3">
                            <a href="<?php echo e(route('shop-products.show', $relatedProduct)); ?>" class="text-decoration-none">
                                <div class="card h-100 shadow-sm product-card">

                                    
                                    <div class="overflow-hidden bg-light" style="height: 180px;">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($relatedProduct->thumbnail): ?>
                                            <img src="<?php echo e(asset('public/assets/' . $relatedProduct->thumbnail)); ?>"
                                                 alt="<?php echo e($relatedProduct->product_name); ?>"
                                                 class="w-100 h-100"
                                                 style="object-fit: cover; transition: transform 0.3s ease;">
                                        <?php else: ?>
                                            <div class="d-flex align-items-center justify-content-center h-100" style="font-size: 2rem; color: #ccc;">
                                                <i class="bi bi-box-seam"></i>
                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>

                                    <div class="card-body d-flex flex-column">

                                        
                                        <div class="d-flex gap-2 mb-2 flex-wrap">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($relatedProduct->category): ?>
                                                <span class="badge bg-light text-dark" style="font-size: 0.7rem;">
                                                    <?php echo e($relatedProduct->category->name); ?>

                                                </span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            <span class="badge <?php echo e($relatedProduct->status === 'in_stock' ? 'bg-success' : 'bg-danger'); ?>"
                                                  style="font-size: 0.7rem;">
                                                <?php echo e($relatedProduct->status === 'in_stock' ? 'In Stock' : 'Out of Stock'); ?>

                                            </span>
                                        </div>

                                        
                                        <h6 class="card-title fw-bold mb-2" style="font-size: 0.95rem;">
                                            <?php echo e($relatedProduct->product_name); ?>

                                        </h6>

                                        
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($relatedProduct->description): ?>
                                            <p class="card-text text-muted small flex-grow-1 mb-3"
                                               style="font-size: 0.85rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                                <?php echo e($relatedProduct->description); ?>

                                            </p>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        
                                        <div class="d-flex align-items-center gap-1 mb-3 text-muted" style="font-size: 0.8rem;">
                                            <i class="bi bi-clock"></i>
                                            <span><?php echo e($relatedProduct->working_days); ?> day(s)</span>
                                        </div>

                                        
                                        <div class="d-flex justify-content-between align-items-center mt-auto">
                                            <span class="fw-bold text-success" style="font-size: 1.25rem;">
                                                RWF <?php echo e(number_format($relatedProduct->price, 0, '.', ',')); ?>

                                            </span>
                                            <span class="btn btn-sm btn-success">
                                                <i class="bi bi-eye me-1"></i> View
                                            </span>
                                        </div>

                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </section>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    </div>
</main>


<div class="modal fade" id="imageModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            <div class="modal-body p-0">
                <img id="modalImage" src="" alt="Full view" class="w-100 rounded-3">
            </div>
        </div>
    </div>
</div>

<style>
    .product-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        overflow: hidden;
        border: none;
    }

    .product-card:hover {
        box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04) !important;
        transform: translateY(-4px);
    }

    .product-card:hover img {
        transform: scale(1.05);
    }

    .py-md-20 { padding-top: 5rem; padding-bottom: 5rem; }

    @media (max-width: 768px) {
        .py-md-20 { padding-top: 3rem; padding-bottom: 3rem; }
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/front/pages/shopproduct.blade.php ENDPATH**/ ?>