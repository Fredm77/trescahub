

<?php $__env->startSection('title', 'Create Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold mb-0"><i class="bi bi-plus-circle-fill me-2 text-primary"></i>Create Category</h4>
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back
    </a>
</div>

<div class="card">
    <div class="card-body p-4">
        <form action="<?php echo e(route('categories.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="row g-3">

                
                <div class="col-md-6">
                    <label for="title" class="form-label fw-semibold">
                        Title <span class="text-danger">*</span>
                    </label>
                    <input type="text" id="title" name="title"
                           class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('title')); ?>" placeholder="e.g. Electronics" required>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="col-md-6">
                    <label for="slug" class="form-label fw-semibold">
                        Slug <small class="text-muted fw-normal">(auto-generated if blank)</small>
                    </label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-link-45deg"></i></span>
                        <input type="text" id="slug" name="slug"
                               class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               value="<?php echo e(old('slug')); ?>" placeholder="e.g. electronics">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Classification <span class="text-danger">*</span>
                        <small class="text-muted fw-normal">(type &amp; press Add)</small>
                    </label>

                    <div class="input-group mb-2">
                        <input type="text" id="classification-input" class="form-control"
                               placeholder="e.g. Electronics">
                        <button type="button" class="btn btn-outline-primary" id="add-classification">
                            <i class="bi bi-plus-lg"></i> Add
                        </button>
                    </div>

                    
                    <div id="classification-tags" class="d-flex flex-wrap gap-2 mb-1"></div>

                    
                    <div id="classification-inputs"></div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['classification_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['classification_name.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="col-md-6">
                    <label class="form-label fw-semibold">
                        Subcategories <small class="text-muted fw-normal">(type &amp; press Add)</small>
                    </label>

                    <div class="input-group mb-2">
                        <input type="text" id="subcategory-input" class="form-control"
                               placeholder="e.g. Mobile Phones">
                        <button type="button" class="btn btn-outline-primary" id="add-subcategory">
                            <i class="bi bi-plus-lg"></i> Add
                        </button>
                    </div>

                    
                    <div id="subcategory-tags" class="d-flex flex-wrap gap-2 mb-1"></div>

                    
                    <div id="subcategory-inputs"></div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['subcategory.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div class="col-12">
                    <label for="description" class="form-label fw-semibold">Description</label>
                    <textarea id="description" name="description" rows="4"
                              class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              placeholder="Short description…"><?php echo e(old('description')); ?></textarea>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

            </div>

            <hr class="my-4">
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-primary px-4">
                    <i class="bi bi-check-lg me-1"></i> Save Category
                </button>
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-outline-secondary px-4">Cancel</a>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// ── Slug auto-generate ──────────────────────────────────────────────────────
const titleInput = document.getElementById('title');
const slugInput  = document.getElementById('slug');
titleInput.addEventListener('input', () => {
    if (slugInput.dataset.manual) return;
    slugInput.value = titleInput.value.toLowerCase().trim()
        .replace(/[^\w\s-]/g, '').replace(/[\s_]+/g, '-').replace(/^-+|-+$/g, '');
});
slugInput.addEventListener('input', () => {
    slugInput.dataset.manual = slugInput.value ? '1' : '';
});

// ── Generic tag-list builder ────────────────────────────────────────────────
function makeTagManager({ inputId, addBtnId, tagsId, hiddenId, inputName }) {
    const inputEl  = document.getElementById(inputId);
    const addBtn   = document.getElementById(addBtnId);
    const tagsDiv  = document.getElementById(tagsId);
    const hiddenDiv = document.getElementById(hiddenId);
    const items    = []; // array of strings

    function render() {
        tagsDiv.innerHTML   = '';
        hiddenDiv.innerHTML = '';

        items.forEach((value, index) => {
            // Badge tag
            const badge = document.createElement('span');
            badge.className = 'badge bg-primary d-flex align-items-center gap-1 px-2 py-2';
            badge.innerHTML = `${value}
                <button type="button" class="btn-close btn-close-white ms-1"
                        style="font-size:.6rem" data-index="${index}"></button>`;
            badge.querySelector('.btn-close').addEventListener('click', () => {
                items.splice(index, 1);
                render();
            });
            tagsDiv.appendChild(badge);

            // Hidden input
            const inp = document.createElement('input');
            inp.type  = 'hidden';
            inp.name  = inputName;
            inp.value = value;
            hiddenDiv.appendChild(inp);
        });
    }

    function addItem() {
        const val = inputEl.value.trim();
        if (!val) return;
        if (items.includes(val)) {
            inputEl.classList.add('is-invalid');
            setTimeout(() => inputEl.classList.remove('is-invalid'), 1500);
            return;
        }
        items.push(val);
        inputEl.value = '';
        inputEl.focus();
        render();
    }

    addBtn.addEventListener('click', addItem);
    inputEl.addEventListener('keydown', e => {
        if (e.key === 'Enter') { e.preventDefault(); addItem(); }
    });

    return { items, render };
}

// ── Classification tag manager ──────────────────────────────────────────────
const classificationManager = makeTagManager({
    inputId:   'classification-input',
    addBtnId:  'add-classification',
    tagsId:    'classification-tags',
    hiddenId:  'classification-inputs',
    inputName: 'classification_name[]',
});

// ── Subcategory tag manager ─────────────────────────────────────────────────
const subcategoryManager = makeTagManager({
    inputId:   'subcategory-input',
    addBtnId:  'add-subcategory',
    tagsId:    'subcategory-tags',
    hiddenId:  'subcategory-inputs',
    inputName: 'subcategory[]',
});

// ── Restore old() values on validation error ────────────────────────────────
<?php if(old('classification_name')): ?>
    <?php $__currentLoopData = old('classification_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        classificationManager.items.push(<?php echo json_encode($val, 15, 512) ?>);
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    classificationManager.render();
<?php endif; ?>

<?php if(old('subcategory')): ?>
    <?php $__currentLoopData = old('subcategory'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        subcategoryManager.items.push(<?php echo json_encode($val, 15, 512) ?>);
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    subcategoryManager.render();
<?php endif; ?>
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/categories/create.blade.php ENDPATH**/ ?>