
<?php $__env->startSection('content'); ?>

<main class="py-12 py-md-20">
    <div class="container">

        
        <div class="text-center mb-5">
            <h1 class="display-4 fw-bold mb-4">Shop & Order</h1>
            <p class="fs-5 text-muted mx-auto" style="max-width: 600px;">
                Physical products, digital services, and tech accessories — delivered to your door or activated instantly.
            </p>
        </div>

        
        <?php
            $activeStatus   = request('status', 'all');
            $activeCategory = request('category', 'all');
            $activeSubcat   = request('subcategory', 'all');
            $searchQuery    = request('search', '');

            $totalCount    = $products->count();
            $inStockCount  = $products->where('status', 'in_stock')->count();
            $outStockCount = $products->where('status', 'out_of_stock')->count();

            $tabs = [
                ['key' => 'all',          'label' => 'All Products', 'count' => $totalCount],
                ['key' => 'in_stock',     'label' => 'In Stock',     'count' => $inStockCount],
                ['key' => 'out_of_stock', 'label' => 'Out of Stock', 'count' => $outStockCount],
            ];
        ?>

        <div class="d-flex justify-content-center gap-3 flex-wrap mt-4 mb-4">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop', array_merge(request()->query(), ['status' => $tab['key']]))); ?>"
                   class="btn btn-sm <?php echo e($activeStatus === $tab['key'] ? 'btn-primary' : 'btn-outline-secondary'); ?> d-flex align-items-center gap-2"
                   style="border-radius: 9999px; padding: 0.625rem 1.25rem; font-size: 0.875rem;">
                    <span><?php echo e($tab['label']); ?></span>
                    <span class="badge <?php echo e($activeStatus === $tab['key'] ? 'bg-white text-primary' : 'bg-secondary'); ?>"
                          style="font-size: 0.7rem;">
                        <?php echo e($tab['count']); ?>

                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <div class="row justify-content-center mb-4">
            <div class="col-12 col-md-6" style="max-width: 500px;">
                <form action="<?php echo e(route('shop')); ?>" method="GET" class="input-group input-group-lg">
                    <span class="input-group-text bg-white border-end-0">
                        <i class="bi bi-search"></i>
                    </span>
                    <input type="hidden" name="status"   value="<?php echo e($activeStatus); ?>">
                    <input type="hidden" name="category" value="<?php echo e($activeCategory); ?>">
                    <input type="text"
                           name="search"
                           class="form-control border-start-0"
                           placeholder="Search products..."
                           value="<?php echo e($searchQuery); ?>"
                           onchange="this.form.submit()"
                           style="font-size: 0.875rem;">
                </form>
            </div>
        </div>

        
        <div class="d-flex justify-content-center flex-wrap gap-2 mb-2">
            <a href="<?php echo e(route('shop', array_merge(request()->query(), ['category' => 'all', 'subcategory' => 'all']))); ?>"
               class="btn btn-sm <?php echo e($activeCategory === 'all' ? 'btn-secondary' : 'btn-outline-secondary'); ?>"
               style="border-radius: 9999px; padding: 0.375rem 1rem; font-size: 0.875rem;">
                All
            </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('shop', array_merge(request()->query(), ['category' => $cat->slug, 'subcategory' => 'all']))); ?>"
                   class="btn btn-sm <?php echo e($activeCategory === $cat->slug ? 'btn-secondary' : 'btn-outline-secondary'); ?>"
                   style="border-radius: 9999px; padding: 0.375rem 1rem; font-size: 0.875rem;">
                    <?php echo e($cat->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeCategory !== 'all'): ?>
            <?php
                $selectedParent = $parentCategories->firstWhere('slug', $activeCategory);
            ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedParent && $selectedParent->subcategories->count() > 0): ?>
                <div class="d-flex justify-content-center flex-wrap gap-2 mb-4">
                    <a href="<?php echo e(route('shop', array_merge(request()->query(), ['subcategory' => 'all']))); ?>"
                       class="btn btn-sm <?php echo e($activeSubcat === 'all' ? 'btn-dark' : 'btn-outline-dark'); ?>"
                       style="border-radius: 9999px; padding: 0.3rem 0.9rem; font-size: 0.8rem;">
                        All <?php echo e($selectedParent->name); ?>

                    </a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $selectedParent->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('shop', array_merge(request()->query(), ['subcategory' => $sub->slug]))); ?>"
                           class="btn btn-sm <?php echo e($activeSubcat === $sub->slug ? 'btn-dark' : 'btn-outline-dark'); ?>"
                           style="border-radius: 9999px; padding: 0.3rem 0.9rem; font-size: 0.8rem;">
                            <?php echo e($sub->name); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($products->isEmpty()): ?>
            <div class="alert alert-light border mt-5 p-5 text-center">
                <p class="text-muted mb-3">No products found matching your criteria.</p>
                <a href="<?php echo e(route('shop')); ?>" class="btn btn-outline-secondary btn-sm">
                    Clear Filters
                </a>
            </div>
        <?php else: ?>
            <div class="row g-4 mt-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                        <a href="<?php echo e(route('shop-products.show', $product)); ?>" class="text-decoration-none">
                            <div class="card h-100 product-card shadow-sm">

                                
                                <div class="product-img-wrap">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->thumbnail): ?>
                                        <img src="<?php echo e(asset('public/assets/' . $product->thumbnail)); ?>"
                                             alt="<?php echo e($product->product_name); ?>"
                                             class="product-img">
                                    <?php else: ?>
                                        <div class="product-img-placeholder">
                                            <i class="bi bi-box-seam"></i>
                                        </div>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>

                                <div class="card-body d-flex flex-column">

                                    
                                    <div class="d-flex gap-2 mb-2 flex-wrap">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->category): ?>
                                            <span class="badge bg-light text-dark border" style="font-size: 0.7rem;">
                                                <?php echo e($product->category->name); ?>

                                            </span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <span class="badge <?php echo e($product->status === 'in_stock' ? 'bg-success' : 'bg-danger'); ?>"
                                              style="font-size: 0.7rem;">
                                            <?php echo e($product->status === 'in_stock' ? 'In Stock' : 'Out of Stock'); ?>

                                        </span>
                                    </div>

                                    
                                    <h5 class="card-title fw-bold mb-2" style="font-size: 0.95rem;">
                                        <?php echo e($product->product_name); ?>

                                    </h5>

                                    
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->description): ?>
                                        <p class="card-text text-muted small flex-grow-1 mb-3"
                                           style="font-size: 0.85rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                            <?php echo e($product->description); ?>

                                        </p>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                    
                                    <div class="d-flex align-items-center gap-1 mb-3 text-muted" style="font-size: 0.8rem;">
                                        <i class="bi bi-clock"></i>
                                        <span><?php echo e($product->working_days); ?> working day(s)</span>
                                    </div>

                                    
                                    <div class="d-flex justify-content-between align-items-center mt-auto">
                                        <span class="fw-bold fs-5 text-primary">
                                            RWF <?php echo e(number_format($product->price, 0, '.', ',')); ?>

                                        </span>
                                        <span class="btn btn-sm btn-primary">
                                            <i class="bi bi-eye me-1"></i> View
                                        </span>
                                    </div>

                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        
        <div class="alert alert-light border mt-5 p-5 text-center">
            <h4 class="fw-bold mb-2">Can't Find What You Need?</h4>
            <p class="text-muted mb-4">
                We can source any product for you through our Assisted Online Purchase service.
            </p>
            <a href="<?php echo e(route('request-service')); ?>" class="btn btn-primary">
                <i class="bi bi-question-circle me-2"></i>Request a Product
            </a>
        </div>

    </div>
</main>

<style>
    .py-md-20 { padding-top: 5rem; padding-bottom: 5rem; }

    @media (max-width: 768px) {
        .py-md-20 { padding-top: 3rem; padding-bottom: 3rem; }
    }

    .product-card {
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        overflow: hidden;
        border: none;
    }

    .product-card:hover {
        box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04) !important;
        transform: translateY(-4px);
    }

    .product-img-wrap {
        width: 100%;
        height: 180px;
        overflow: hidden;
        background: #f3f4f6;
    }

    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .product-card:hover .product-img { transform: scale(1.05); }

    .product-img-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 3rem;
        color: #9ca3af;
    }

    .text-primary { color: #16a34a !important; }
    .btn-primary  { background-color: #16a34a; border-color: #16a34a; }
    .btn-primary:hover { background-color: #15803d; border-color: #15803d; }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/front/pages/shop.blade.php ENDPATH**/ ?>