

<?php $__env->startSection('title', 'Create Service'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold mb-0"><i class="bi bi-plus-circle-fill me-2 text-primary"></i>Create Service</h4>
    <a href="<?php echo e(route('services.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left me-1"></i> Back
    </a>
</div>

<form action="<?php echo e(route('services.store')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>


<div class="card mb-4">
    <div class="card-header bg-white fw-semibold">Basic Information</div>
    <div class="card-body">
        <div class="row g-3">

            <div class="col-md-6">
                <label class="form-label fw-semibold">Title <span class="text-danger">*</span></label>
                <input type="text" name="title" id="title"
                       class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('title')); ?>" required>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-semibold">
                    Slug <small class="text-muted fw-normal">(auto-generated if blank)</small>
                </label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-link-45deg"></i></span>
                    <input type="text" name="slug" id="slug"
                           class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('slug')); ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Price <span class="text-danger">*</span></label>
                <div class="input-group">
                    <span class="input-group-text">RWF</span>
                    <input type="number" name="price" step="0.01" min="0"
                           class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('price', '0.00')); ?>" required>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Working Day</label>
                <input type="text" name="working_day"
                       class="form-control <?php $__errorArgs = ['working_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       value="<?php echo e(old('working_day')); ?>" placeholder="e.g. Mon - Fri or 3-5 Business Days">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['working_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="col-12">
                <label class="form-label fw-semibold">Description</label>
                <textarea name="description" rows="4"
                          class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                          placeholder="Describe this service…"><?php echo e(old('description')); ?></textarea>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

        </div>
    </div>
</div>


<div class="card mb-4">
    <div class="card-header bg-white fw-semibold">Service Status</div>
    <div class="card-body">
        <div class="row g-3">

            <div class="col-md-6">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch"
                           name="is_popular" id="is_popular" value="1"
                           <?php echo e(old('is_popular') ? 'checked' : ''); ?>>
                    <label class="form-check-label fw-semibold" for="is_popular">
                        <i class="bi bi-fire text-warning me-1"></i> Mark as Popular
                    </label>
                </div>
                <small class="text-muted d-block mt-1">
                    Popular services appear in the <code>popular-service</code> section when viewed.
                </small>
            </div>

            <div class="col-md-6">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch"
                           name="is_in_stock" id="is_in_stock" value="1"
                           <?php echo e(old('is_in_stock') ? 'checked' : ''); ?>>
                    <label class="form-check-label fw-semibold" for="is_in_stock">
                        <i class="bi bi-check-circle text-success me-1"></i> Mark as In Stock
                    </label>
                </div>
                <small class="text-muted d-block mt-1">
                    In-stock services appear in the <code>our-services</code> section when viewed.
                </small>
            </div>

        </div>
    </div>
</div>


<div class="card mb-4">
    <div class="card-header bg-white fw-semibold">Classification & Subcategory</div>
    <div class="card-body">
        <div class="row g-3">

            <div class="col-md-6">
                <label class="form-label fw-semibold">
                    Classification <small class="text-muted fw-normal">(Category)</small>
                </label>
                <select name="classification_name" id="classification-select"
                        class="form-select <?php $__errorArgs = ['classification_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="">— Select classification —</option>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $classifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"
                            <?php echo e(old('classification_name') == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->title); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </select>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['classification_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-semibold">
                    Subcategories <small class="text-muted fw-normal">(loaded from classification)</small>
                </label>

                <div class="input-group mb-2">
                    <select id="subcategory-select" class="form-select" disabled>
                        <option value="">— Select classification first —</option>
                    </select>
                    <button type="button" class="btn btn-outline-primary" id="add-subcategory" disabled>
                        <i class="bi bi-plus-lg"></i> Add
                    </button>
                </div>

                <div id="subcategory-tags" class="d-flex flex-wrap gap-2 mb-1"></div>
                <div id="subcategory-inputs"></div>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['subcategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['subcategory.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

        </div>
    </div>
</div>


<div class="card mb-4">
    <div class="card-header bg-white fw-semibold">What's Included</div>
    <div class="card-body">
        <div id="what-included-list">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(old('what_included')): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = old('what_included'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="input-group mb-2 what-included-row">
                        <input type="text" name="what_included[]" class="form-control"
                               value="<?php echo e($item); ?>" placeholder="e.g. Free WiFi">
                        <button type="button" class="btn btn-outline-danger remove-row">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <div class="input-group mb-2 what-included-row">
                    <input type="text" name="what_included[]" class="form-control"
                           placeholder="e.g. Free WiFi">
                    <button type="button" class="btn btn-outline-danger remove-row">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <button type="button" class="btn btn-outline-primary btn-sm mt-1" id="add-what-included">
            <i class="bi bi-plus-lg me-1"></i> Add Item
        </button>
    </div>
</div>


<div class="card mb-4">
    <div class="card-header bg-white fw-semibold">How Service Works</div>
    <div class="card-body">
        <div id="how-works-list">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(old('how_service_works')): ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = old('how_service_works'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="input-group mb-2 how-works-row">
                        <span class="input-group-text step-num"><?php echo e($i + 1); ?></span>
                        <input type="text" name="how_service_works[]" class="form-control"
                               value="<?php echo e($step); ?>" placeholder="Describe this step…">
                        <button type="button" class="btn btn-outline-danger remove-row">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php else: ?>
                <div class="input-group mb-2 how-works-row">
                    <span class="input-group-text step-num">1</span>
                    <input type="text" name="how_service_works[]" class="form-control"
                           placeholder="Describe this step…">
                    <button type="button" class="btn btn-outline-danger remove-row">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <button type="button" class="btn btn-outline-primary btn-sm mt-1" id="add-how-works">
            <i class="bi bi-plus-lg me-1"></i> Add Step
        </button>
    </div>
</div>


<div class="card mb-4">
    <div class="card-header bg-white fw-semibold">Images</div>
    <div class="card-body">
        <div class="row g-3">

            <div class="col-md-6">
                <label class="form-label fw-semibold">Thumbnail</label>
                <input type="file" name="thumbnail" accept="image/*"
                       class="form-control <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       id="thumbnail-input">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="mt-2" id="thumbnail-preview"></div>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-semibold">Other Images <small class="text-muted">(multiple)</small></label>
                <input type="file" name="other_images[]" accept="image/*" multiple
                       class="form-control <?php $__errorArgs = ['other_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       id="other-images-input">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['other_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['other_images.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <div class="mt-2 d-flex flex-wrap gap-2" id="other-images-preview"></div>
            </div>

        </div>
    </div>
</div>

<div class="d-flex gap-2 mb-5">
    <button type="submit" class="btn btn-primary px-4">
        <i class="bi bi-check-lg me-1"></i> Save Service
    </button>
    <a href="<?php echo e(route('services.index')); ?>" class="btn btn-outline-secondary px-4">Cancel</a>
</div>

</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// ── Slug auto-generate ──────────────────────────────────────────────────────
const titleEl = document.getElementById('title');
const slugEl  = document.getElementById('slug');
titleEl.addEventListener('input', () => {
    if (slugEl.dataset.manual) return;
    slugEl.value = titleEl.value.toLowerCase().trim()
        .replace(/[^\w\s-]/g, '').replace(/[\s_]+/g, '-').replace(/^-+|-+$/g, '');
});
slugEl.addEventListener('input', () => { slugEl.dataset.manual = slugEl.value ? '1' : ''; });

// ── Mutual exclusivity: popular & in_stock can't both be checked ────────────
const isPopularEl  = document.getElementById('is_popular');
const isInStockEl  = document.getElementById('is_in_stock');

isPopularEl.addEventListener('change', () => {
    if (isPopularEl.checked) isInStockEl.checked = false;
});
isInStockEl.addEventListener('change', () => {
    if (isInStockEl.checked) isPopularEl.checked = false;
});

// ── Classification → load subcategories via AJAX ────────────────────────────
const classificationSelect = document.getElementById('classification-select');
const subcategorySelect    = document.getElementById('subcategory-select');
const addSubBtn            = document.getElementById('add-subcategory');
const subcategoryTags      = document.getElementById('subcategory-tags');
const subcategoryInputs    = document.getElementById('subcategory-inputs');
const selectedSubs         = new Map();

function renderSubTags() {
    subcategoryTags.innerHTML   = '';
    subcategoryInputs.innerHTML = '';
    selectedSubs.forEach((name, value) => {
        const badge = document.createElement('span');
        badge.className = 'badge bg-primary d-flex align-items-center gap-1 px-2 py-2';
        badge.innerHTML = `${name}
            <button type="button" class="btn-close btn-close-white ms-1"
                style="font-size:.6rem" data-val="${value}"></button>`;
        badge.querySelector('.btn-close').addEventListener('click', () => {
            selectedSubs.delete(value);
            renderSubTags();
        });
        subcategoryTags.appendChild(badge);

        const inp = document.createElement('input');
        inp.type  = 'hidden';
        inp.name  = 'subcategory[]';
        inp.value = value;
        subcategoryInputs.appendChild(inp);
    });
}

classificationSelect.addEventListener('change', async function () {
    const categoryId = this.value;

    subcategorySelect.innerHTML = '<option value="">Loading…</option>';
    subcategorySelect.disabled  = true;
    addSubBtn.disabled          = true;
    selectedSubs.clear();
    renderSubTags();

    if (!categoryId) {
        subcategorySelect.innerHTML = '<option value="">— Select classification first —</option>';
        return;
    }

    try {
        const res  = await fetch(`/admin/services/subcategories?category_id=${categoryId}`, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        });

        if (!res.ok) throw new Error('Server error');

        const data = await res.json();

        subcategorySelect.innerHTML = '<option value="">— Select subcategory —</option>';

        if (!data.length) {
            subcategorySelect.innerHTML = '<option value="">No subcategories found</option>';
            return;
        }

        data.forEach(sub => {
            const opt       = document.createElement('option');
            opt.value       = sub;
            opt.textContent = sub;
            subcategorySelect.appendChild(opt);
        });

        subcategorySelect.disabled = false;
        addSubBtn.disabled         = false;

    } catch (e) {
        subcategorySelect.innerHTML = '<option value="">Error loading subcategories</option>';
    }
});

addSubBtn.addEventListener('click', () => {
    const opt = subcategorySelect.options[subcategorySelect.selectedIndex];
    if (!opt || !opt.value) return;
    selectedSubs.set(opt.value, opt.value);
    renderSubTags();
});

// ── Restore old() on validation failure ────────────────────────────────────
<?php if(old('subcategory') && old('classification_name')): ?>
    (async () => {
        classificationSelect.value = "<?php echo e(old('classification_name')); ?>";
        classificationSelect.dispatchEvent(new Event('change'));
        await new Promise(r => setTimeout(r, 700));
        const oldSubs = <?php echo json_encode(old('subcategory', []), 512) ?>;
        oldSubs.forEach(val => selectedSubs.set(val, val));
        renderSubTags();
    })();
<?php endif; ?>

// ── Dynamic row: What's Included ───────────────────────────────────────────
document.getElementById('add-what-included').addEventListener('click', () => {
    const row = document.createElement('div');
    row.className = 'input-group mb-2 what-included-row';
    row.innerHTML = `<input type="text" name="what_included[]" class="form-control" placeholder="e.g. Free WiFi">
        <button type="button" class="btn btn-outline-danger remove-row"><i class="bi bi-trash"></i></button>`;
    document.getElementById('what-included-list').appendChild(row);
    bindRemove(row);
});

// ── Dynamic row: How Service Works ─────────────────────────────────────────
document.getElementById('add-how-works').addEventListener('click', () => {
    const list  = document.getElementById('how-works-list');
    const count = list.querySelectorAll('.how-works-row').length + 1;
    const row   = document.createElement('div');
    row.className = 'input-group mb-2 how-works-row';
    row.innerHTML = `<span class="input-group-text step-num">${count}</span>
        <input type="text" name="how_service_works[]" class="form-control" placeholder="Describe this step…">
        <button type="button" class="btn btn-outline-danger remove-row"><i class="bi bi-trash"></i></button>`;
    list.appendChild(row);
    bindRemove(row);
    renumberSteps();
});

function bindRemove(row) {
    row.querySelector('.remove-row').addEventListener('click', () => {
        row.remove();
        renumberSteps();
    });
}

function renumberSteps() {
    document.querySelectorAll('#how-works-list .step-num').forEach((el, i) => {
        el.textContent = i + 1;
    });
}

document.querySelectorAll('.remove-row').forEach(btn => {
    btn.addEventListener('click', () => {
        btn.closest('.input-group').remove();
        renumberSteps();
    });
});

// ── Image preview ──────────────────────────────────────────────────────────
document.getElementById('thumbnail-input').addEventListener('change', function () {
    const preview = document.getElementById('thumbnail-preview');
    preview.innerHTML = '';
    if (this.files[0]) {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(this.files[0]);
        img.className = 'rounded';
        img.style = 'width:100px;height:100px;object-fit:cover';
        preview.appendChild(img);
    }
});

document.getElementById('other-images-input').addEventListener('change', function () {
    const preview = document.getElementById('other-images-preview');
    preview.innerHTML = '';
    [...this.files].forEach(file => {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        img.className = 'rounded';
        img.style = 'width:80px;height:80px;object-fit:cover';
        preview.appendChild(img);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('front.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/services/create.blade.php ENDPATH**/ ?>