
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <h1 class="h3 mb-4">Create Shop Product</h1>

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.shop-products.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        
                        <div class="mb-3">
                            <label for="product_name" class="form-label fw-bold">Product Name *</label>
                            <input type="text"
                                   class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="product_name" name="product_name"
                                   value="<?php echo e(old('product_name')); ?>"
                                   placeholder="e.g., Dell Laptop XPS 15"
                                   required>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="row">
                            
                            <div class="col-md-4 mb-3">
                                <label for="status" class="form-label fw-bold">Status *</label>
                                <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="status" name="status" required>
                                    <option value="in_stock"    <?php echo e(old('status', 'in_stock') === 'in_stock'    ? 'selected' : ''); ?>>In Stock</option>
                                    <option value="out_of_stock" <?php echo e(old('status') === 'out_of_stock' ? 'selected' : ''); ?>>Out of Stock</option>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label for="price" class="form-label fw-bold">Price (RWF) *</label>
                                <div class="input-group">
                                    <span class="input-group-text">RWF</span>
                                    <input type="number"
                                           class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="price" name="price"
                                           value="<?php echo e(old('price')); ?>"
                                           placeholder="e.g., 500000"
                                           min="0" step="1" required>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <div class="col-md-4 mb-3">
                                <label for="working_days" class="form-label fw-bold">Working Days *</label>
                                <input type="number"
                                       class="form-control <?php $__errorArgs = ['working_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="working_days" name="working_days"
                                       value="<?php echo e(old('working_days', 1)); ?>"
                                       min="1" required>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['working_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input type="checkbox"
                                       class="form-check-input"
                                       id="is_popular" 
                                       name="is_popular"
                                       value="1"
                                       <?php echo e(old('is_popular') ? 'checked' : ''); ?>>
                                <label class="form-check-label fw-bold" for="is_popular">
                                    <i class="bi bi-star-fill" style="color: #ffc107;"></i>
                                    Mark as Popular Product
                                </label>
                                <small class="d-block text-muted mt-1">
                                    ✅ When checked: Shows in BOTH popular section AND shop page  
                                    ❌ When unchecked: Shows ONLY in shop page
                                </small>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <label for="description" class="form-label fw-bold">Description</label>
                            <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      id="description" name="description"
                                      rows="3"
                                      placeholder="Product description..."><?php echo e(old('description')); ?></textarea>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="row">
                            
                            <div class="col-md-6 mb-3">
                                <label for="shop_category_id" class="form-label fw-bold">Parent Category *</label>
                                <select class="form-select <?php $__errorArgs = ['shop_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="shop_category_id" name="shop_category_id" required>
                                    <option value="">— Select Parent Category —</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>"
                                                data-subcategories="<?php echo e($cat->subcategories->toJson()); ?>"
                                                <?php echo e(old('shop_category_id') == $cat->id ? 'selected' : ''); ?>>
                                            <?php echo e($cat->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['shop_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            
                            <div class="col-md-6 mb-3">
                                <label for="subcategory_id" class="form-label fw-bold">Subcategory</label>
                                <select class="form-select <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="subcategory_id" name="subcategory_id">
                                    <option value="">— Select Subcategory —</option>
                                </select>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">
                                Features
                                <span class="text-muted fw-normal">(e.g., Waterproof, Fast Charging)</span>
                            </label>
                            <div id="features-container">
                                <div class="input-group mb-2">
                                    <input type="text" class="form-control"
                                           name="features[]"
                                           placeholder="e.g., Fast Charging"
                                           value="<?php echo e(old('features.0')); ?>">
                                    <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="addFeature()">
                                + Add Feature
                            </button>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">
                                Specifications
                                <span class="text-muted fw-normal">(e.g., RAM → 8GB, Color → Black)</span>
                            </label>
                            <div id="specs-container">
                                <div class="spec-row d-flex gap-2 mb-2">
                                    <input type="text" class="form-control"
                                           name="specifications[0][label]"
                                           placeholder="Label (e.g., RAM)"
                                           value="<?php echo e(old('specifications.0.label')); ?>">
                                    <input type="text" class="form-control"
                                           name="specifications[0][value]"
                                           placeholder="Value (e.g., 8GB)"
                                           value="<?php echo e(old('specifications.0.value')); ?>">
                                    <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="addSpec()">
                                + Add Specification
                            </button>
                        </div>

                        
                        <div class="mb-3">
                            <label for="thumbnail" class="form-label fw-bold">Thumbnail Image</label>
                            <input type="file"
                                   class="form-control <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="thumbnail" name="thumbnail"
                                   accept="image/*"
                                   onchange="previewThumbnail(this)">
                            <div id="thumbnail-preview" class="mt-2"></div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div class="mb-4">
                            <label for="images" class="form-label fw-bold">Other Images</label>
                            <input type="file"
                                   class="form-control <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   id="images" name="images[]"
                                   accept="image/*" multiple
                                   onchange="previewImages(this)">
                            <small class="text-muted">You can select multiple images</small>
                            <div id="images-preview" class="d-flex flex-wrap gap-2 mt-2"></div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">Create Product</button>
                            <a href="<?php echo e(route('admin.shop-products.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // ── Category → Subcategory ─────────────────────────────────────────────
    const categorySelect    = document.getElementById('shop_category_id');
    const subcategorySelect = document.getElementById('subcategory_id');
    const oldSubcat         = "<?php echo e(old('subcategory_id')); ?>";

    function loadSubcategories() {
        const selected = categorySelect.options[categorySelect.selectedIndex];
        subcategorySelect.innerHTML = '<option value="">— Select Subcategory —</option>';

        if (!selected || !selected.dataset.subcategories) return;

        const subs = JSON.parse(selected.dataset.subcategories);
        subs.forEach(sub => {
            const opt       = document.createElement('option');
            opt.value       = sub.id;
            opt.textContent = sub.name;
            if (oldSubcat == sub.id) opt.selected = true;
            subcategorySelect.appendChild(opt);
        });
    }

    categorySelect.addEventListener('change', loadSubcategories);
    loadSubcategories();

    // ── Features ──────────────────────────────────────────────────────────
    function addFeature() {
        const container = document.getElementById('features-container');
        const group     = document.createElement('div');
        group.className = 'input-group mb-2';
        group.innerHTML = `
            <input type="text" class="form-control" name="features[]" placeholder="e.g., Fast Charging">
            <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                <i class="bi bi-trash"></i>
            </button>`;
        container.appendChild(group);
        group.querySelector('input').focus();
    }

    // ── Specifications ─────────────────────────────────────────────────────
    let specIndex = 1;
    function addSpec() {
        const container = document.getElementById('specs-container');
        const row       = document.createElement('div');
        row.className   = 'spec-row d-flex gap-2 mb-2';
        row.innerHTML   = `
            <input type="text" class="form-control" name="specifications[${specIndex}][label]" placeholder="Label (e.g., RAM)">
            <input type="text" class="form-control" name="specifications[${specIndex}][value]" placeholder="Value (e.g., 8GB)">
            <button type="button" class="btn btn-outline-danger" onclick="removeRow(this)">
                <i class="bi bi-trash"></i>
            </button>`;
        container.appendChild(row);
        row.querySelector('input').focus();
        specIndex++;
    }

    // ── Remove row ─────────────────────────────────────────────────────────
    function removeRow(btn) {
        btn.closest('.input-group, .spec-row').remove();
    }

    // ── Image Previews ─────────────────────────────────────────────────────
    function previewThumbnail(input) {
        const preview = document.getElementById('thumbnail-preview');
        preview.innerHTML = '';
        if (input.files && input.files[0]) {
            const img    = document.createElement('img');
            img.src      = URL.createObjectURL(input.files[0]);
            img.className = 'rounded';
            img.style    = 'width:100px;height:100px;object-fit:cover;';
            preview.appendChild(img);
        }
    }

    function previewImages(input) {
        const preview = document.getElementById('images-preview');
        preview.innerHTML = '';
        Array.from(input.files).forEach(file => {
            const img    = document.createElement('img');
            img.src      = URL.createObjectURL(file);
            img.className = 'rounded';
            img.style    = 'width:80px;height:80px;object-fit:cover;';
            preview.appendChild(img);
        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/afrino3/trescahub.afrinnovators.co.rw/resources/views/shop-products/create.blade.php ENDPATH**/ ?>