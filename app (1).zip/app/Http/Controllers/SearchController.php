<?php

namespace App\Http\Controllers;

use App\Models\Service;
use App\Models\ShopProduct;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function live(Request $request)
    {
        $q = trim($request->input('q', ''));

        if (strlen($q) < 2) {
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json([]);
            }
            return view('front.pages.search', ['q' => $q, 'services' => collect(), 'products' => collect()]);
        }

        $services = Service::with('category')
            ->where('is_in_stock', true)
            ->where(function ($query) use ($q) {
                $query->where('title', 'like', "%{$q}%")
                      ->orWhere('description', 'like', "%{$q}%");
            })
            ->limit(5)
            ->get();

        $products = ShopProduct::with('category')
            ->where(function ($query) use ($q) {
                $query->where('product_name', 'like', "%{$q}%")
                      ->orWhere('description', 'like', "%{$q}%");
            })
            ->limit(5)
            ->get();

        if ($request->expectsJson() || $request->ajax()) {
            return response()->json(
                $services->map(fn($s) => [
                    'type'      => 'service',
                    'title'     => $s->title,
                    'subtitle'  => $s->category->title ?? '',
                    'thumbnail' => $s->thumbnail ? asset($s->thumbnail) : null,
                    'url'       => route('service.show', $s->slug),
                ])->merge(
                $products->map(fn($p) => [
                    'type'      => 'product',
                    'title'     => $p->product_name,
                    'subtitle'  => $p->category->name ?? '',
                    'thumbnail' => $p->thumbnail ? asset('assets/' . $p->thumbnail) : null,
                    'url'       => route('shop-products.show', $p->slug),
                ]))->values()
            );
        }

        return view('front.pages.search', compact('q', 'services', 'products'));
    }
}